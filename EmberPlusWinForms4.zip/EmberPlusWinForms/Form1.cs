﻿using Lawo.ComponentModel;
using Lawo.EmberPlusSharp.Ember;
using Lawo.EmberPlusSharp.Model;
using Lawo.EmberPlusSharp.S101;
using Lawo.Reflection;
using Lawo.Threading.Tasks;
using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using static EmberPlusWinForms.Form1;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;


namespace EmberPlusWinForms
{
    public partial class Form1 : Form
    {
       // public static Form1 Instance;  // Now you can access the form from static code
        bool checkboxEnabled = false;
        int buttonNR = 1;

        public Form1()
        {
            InitializeComponent();
        //     Instance = this;
            // Subscribe to the CheckedChanged event
            checkBox1.CheckedChanged += CheckBox1_CheckedChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Stop();
            Task startEmberPlusListenerAsync = StartEmberPlusListenerAsync();
        }

        private static async Task<S101Client> ConnectAsync(string host, int port)
        {
            var tcpClient = new TcpClient();
            await tcpClient.ConnectAsync(host, port);
            var stream = tcpClient.GetStream();
            Thread.Sleep(300);

            return new S101Client(tcpClient, stream.ReadAsync, stream.WriteAsync);
        }


        /*
        //-----------------------------------------------------------------------------------------------------------------------------------------
        // Auron  setters and getters    // "/auron/modules/module_{i}/path/fader"
        //-----------------------------------------------------------------------------------------------------------------------------------------

        private sealed class AuronRoot : Root<AuronRoot>
        {
            internal auro auron {  get; private set; }
        }

        private sealed class auro : FieldNode<auro>
        {
            //  [Element(Identifier = "auron")]
            // internal IntegerParameter test { get; private set; }           // Deze staat hier als test, maar wordt niet gebruikt.
            internal Modules modules { get; private set; }
        }

        private sealed class Modules : FieldNode<Modules>
        {
            // [Element(Identifier = "modules")]
            internal Module_1 module_1 { get; private set; }
        }

        private sealed class Module_1 : FieldNode<Module_1>
        {
            //[Element(Identifier = "module_1")]
            internal Path path { get; private set; }
        }

        private sealed class Path : FieldNode<Path>
        {
            // [Element(Identifier = "path")]
            internal IntegerParameter fader { get; private set; }
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------
        // Sapphire  setters and getters     "Sapphire/Sources/FPGM 1/Fader/Position"
        //-----------------------------------------------------------------------------------------------------------------------------------------

        private sealed class SapphireRoot : Root<SapphireRoot>
        {
            internal Sapphire Sapphire { get; private set; }
            
        }

        private sealed class Sapphire : FieldNode<Sapphire>
        {
            internal IntegerParameter test { get; private set; }
            //  internal Sources Sources { get; private set; }
            // internal Test Test { get; private set; }                // Deze staat hier als test, maar wordt niet gebruikt.
        }


        private sealed class Sources : FieldNode<Sources>
        {
            [Element(Identifier = "FPGM 1")]
            internal Source Fpgm1 { get; private set; }
        }

        private sealed class Source : FieldNode<Source>
        {
            internal Fader Fader { get; private set; }
        }

        private sealed class Fader : FieldNode<Fader>
        {
            [Element(Identifier = "dB Value")]
            internal RealParameter DBValue { get; private set; }

            internal IntegerParameter Position { get; private set; }
        }
        */



        //-------------------------------------------------------------------------------------------------------------------------------------

        private sealed class MyRoot : DynamicRoot<MyRoot>
        {
        }

        //-------------------------------------------------------------------------------------------------------------------------------------


        private async Task StartEmberPlusListenerAsync()
        {
            //using (var client = await ConnectAsync("localhost", 9000))                         // zet hier ander poort nummer voor Proxy
            //using (var consumer = await Consumer<AuronRoot>.CreateAsync(client))        // Auron

            //using (var client = await ConnectAsync("localhost", 9000))                      // zet hier ander poort nummer voor Proxy
            //using (var consumer = await Consumer<SapphireRoot>.CreateAsync(client))    // Sapphire

            using (var client = await ConnectAsync("localhost", 9000))                      // zet hier ander poort nummer voor Proxy
            using (var consumer = await Consumer<MyRoot>.CreateAsync(client))           // Beide
            {

                INode root = consumer.Root;


                // var faderpos = (IParameter)root.GetElement("Sapphire/Sources/FPGM 1/Fader/Position");      // Beide
                // var faderpos = consumer.Root.Sapphire.Sources.Fpgm1.Fader.Position;                      // Sapphire
                // var faderpos = consumer.Root.Sapphire.test;                                              // Sapphire test

                 var faderpos = (IParameter)root.GetElement("auron/modules/module_1/path/fader");    // Beide
                // var faderpos = consumer.Root.auron.modules.module_1.path.fader;                       // Auron
               //  var faderpos = consumer.Root.auron.test;                                            // Auron Test

                faderpos.PropertyChanged += (sender, args) =>
                {
                    var updatedValue = (long)((IParameter)sender).Value;    // Receive value
                    this.BeginInvoke((Action)(() =>
                    {
                        int clampedValue = Math.Min(Math.Max((int)updatedValue, trackBar1.Minimum), trackBar1.Maximum);
                        if (trackBar1.Value != clampedValue)
                            trackBar1.Value = clampedValue;

                        textBox1.AppendText($"[IN] Fader.Position changed: {updatedValue}\r\n");
                    }));
                };


                trackBar1.Scroll += async (s, e) =>
                {
                    faderpos.Value = (long)trackBar1.Value;        // Send
                    await consumer.SendAsync();

                    textBox1.AppendText($"[OUT] Sent Fader.Position: {trackBar1.Value}\r\n");
                };

                await Task.Delay(Timeout.Infinite); // Keep app alive
            }
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------




















        private bool isOn = true;

        private  void button1_Click(object sender, EventArgs e)
        {
            isOn = !isOn; // Toggle the boolean value
            button1.Tag = isOn; // Store the value in the Tag property
            buttonNR = 1;
        }

        private  void button2_Click(object sender, EventArgs e)
        {
            isOn = !isOn; // Toggle the boolean value
            button2.Tag = isOn; // Store the value in the Tag property
            buttonNR = 2;
        }



        private void Form1_Activated(object sender, EventArgs e)
        {

        }

        static int tellertje;

        private void timer1_Tick(object sender, EventArgs e)
        {
            tellertje = tellertje + 20;
            trackBar1.Value = tellertje;
            trackBar2.Value = tellertje;
            trackBar3.Value = tellertje;
            trackBar4.Value = tellertje;
            trackBar5.Value = tellertje;
            trackBar6.Value = tellertje;
            trackBar7.Value = tellertje;
            trackBar8.Value = tellertje;
            trackBar9.Value = tellertje;
            trackBar10.Value = tellertje;
            if (tellertje > 1000)
                tellertje = 0;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {

        }
        private void CheckBox1_CheckedChanged(object? sender, EventArgs e)
        {

        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = checkBox1.Checked;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            isOn = !isOn; 
            button3.Tag = isOn;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button4.Tag = isOn;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button5.Tag = isOn;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button6.Tag = isOn;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button7.Tag = isOn;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button8.Tag = isOn;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button9.Tag = isOn;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            isOn = !isOn;
            button10.Tag = isOn;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar8_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar7_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar6_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar10_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar9_Scroll(object sender, EventArgs e)
        {

        }

    }
}
////-----------------------------------------------------------------------------------------------------------------------------------------


//private async Task StartEmberPlusListenerAsync()
//{ 
//    using (var client = await ConnectAsync("localhost", 900))
//    using (var consumer = await Consumer<MyRoot>.CreateAsync(client))
//    {
//        INode root = consumer.Root;

//        // Navigate to the parameters we're interested in.
//        var sapphire = (INode)root.Children.First(c => c.Identifier == "Sapphire");
//        var sources = (INode)sapphire.Children.First(c => c.Identifier == "Sources");
//        var fpgm1 = (INode)sources.Children.First(c => c.Identifier == "FPGM 1");
//        var fader = (INode)fpgm1.Children.First(c => c.Identifier == "Fader");
//       // var level = (IParameter)fader.Children.First(c => c.Identifier == "dB Value");
//        var position = (IParameter)fader.Children.First(c => c.Identifier == "Position");

//        // Set parameters to the desired values.
//        position.Value = 999L;
//        await consumer.SendAsync();
//    }

//}


//public static INode GetNodeByPath(INode root, string path)
//{
//    return path.Split('/')
//               .Aggregate(root, (current, identifier) =>
//                   (INode)current.Children.First(c => c.Identifier == identifier));
//}

////int i = 2;
////var fader = (TrackBar)Controls[$"trackbar{i}"];
////// var ValFaderParam = (IParameter)root.GetElement($"/auron/modules/module_{i}/path/fader");

////// var path = (INode)root.Children.First(c => c.Identifier == ("auron.modules.module_1.path."));


////var path = (INode)GetNodeByPath(root, "auron/modules/module_1/path");


//////var identifiers = new[] { "auron", "modules", $"module_{i}", "path" };
//////var path = identifiers.Aggregate((INode)root, (node, id) => (INode)node.Children.First(c => c.Identifier == id));


//////var auron = (INode)root.Children.First(c => c.Identifier == "auron");
//////var modules = (INode)auron.Children.First(c => c.Identifier == "modules");
//////var module_1 = (INode)modules.Children.First(c => c.Identifier == "module_1");
//////var path = (INode)module_1.Children.First(c => c.Identifier == "path");

////var ValFaderParam = (IParameter)path.Children.First(c => c.Identifier == "fader");


////BindFader(ValFaderParam, fader);

////var button = (Button)Controls[$"button{i}"];
////var stateParam = (IParameter)root.GetElement($"/auron/modules/module_{i}/control/sw_1/state");
////var colorParam = (IParameter)root.GetElement($"/auron/modules/module_{i}/control/sw_1/color_on");
///


//private void BindFader(IParameter faderp, System.Windows.Forms.TrackBar trackBar)
//{
//    faderp.PropertyChanged += (sender, args) =>
//    {
//        var updatedValue = (long)((IParameter)sender).Value;    // Receive value
//        this.BeginInvoke((Action)(() =>
//        { 
//            var parameter = sender as IParameter;
//            if (parameter != null)
//            {
//                textBox1.AppendText($"[IN] {trackBar.Name} changed: {updatedValue}\r\n");
//                int clampedValue = Math.Min(Math.Max((int)updatedValue, trackBar.Minimum), trackBar.Maximum);
//                if (trackBar.Value != clampedValue)
//                    trackBar.Value = clampedValue;
//            }
//        }));
//    };
//    trackBar.ValueChanged += (s, e) =>
//    {
//        int newValue = trackBar.Value;         // Send value
//        faderp.Value = (long)newValue;
//        textBox1.AppendText($"[OUT] Sent {trackBar.Name}: {newValue}\r\n");
//    };
//}

//-----------------------------------------------------------------------------------------------------------------------------------------
//private async Task StartEmberPlusListenerAsync()
//{
//    AsyncPump.Run(
//        async () =>
//    {
//        using (var client = await ConnectAsync("localhost", 9000))
//        using (var consumer = await Consumer<AuronRoot>.CreateAsync(client))
//        {
//            var fader = consumer.Root.Auron.Modules.Module_1.Path.Fader;
//            fader.faderpos.Value = 0L;
//            await consumer.SendAsync();
//        }
//    });
//}



//private async Task StartEmberPlusListenerAsync()
//{
//    using (var client = await ConnectAsync("192.168.1.2", 900))
//    using (var consumer = await Consumer<SapphireRoot>.CreateAsync(client))
//    {
//        var faderPosition = consumer.Root.Sapphire.Sources.Fpgm1.Fader.Position;

//        long newValue = 1000L;

//        faderPosition.Value = newValue;
//        await consumer.SendAsync();
//    }
//}

