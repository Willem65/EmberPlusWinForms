﻿namespace EmberPlusWinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            textBox2 = new TextBox();
            trackBar1 = new TrackBar();
            button2 = new Button();
            trackBar2 = new TrackBar();
            trackBar3 = new TrackBar();
            trackBar4 = new TrackBar();
            trackBar5 = new TrackBar();
            trackBar6 = new TrackBar();
            trackBar7 = new TrackBar();
            trackBar8 = new TrackBar();
            trackBar9 = new TrackBar();
            trackBar10 = new TrackBar();
            checkBox1 = new CheckBox();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            listBox1 = new ListBox();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button38 = new Button();
            button39 = new Button();
            button40 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(26, 386);
            button1.Name = "button1";
            button1.Size = new Size(45, 39);
            button1.TabIndex = 1;
            button1.Tag = "ON";
            button1.Text = "ON";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(93, 12);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(434, 23);
            textBox2.TabIndex = 2;
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(26, 431);
            trackBar1.Maximum = 1023;
            trackBar1.Name = "trackBar1";
            trackBar1.Orientation = Orientation.Vertical;
            trackBar1.Size = new Size(45, 281);
            trackBar1.TabIndex = 3;
            trackBar1.Value = 512;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // button2
            // 
            button2.Location = new Point(106, 386);
            button2.Name = "button2";
            button2.Size = new Size(43, 39);
            button2.TabIndex = 4;
            button2.Tag = "ON";
            button2.Text = "ON";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // trackBar2
            // 
            trackBar2.Location = new Point(104, 431);
            trackBar2.Maximum = 1023;
            trackBar2.Name = "trackBar2";
            trackBar2.Orientation = Orientation.Vertical;
            trackBar2.Size = new Size(45, 281);
            trackBar2.TabIndex = 5;
            trackBar2.Value = 512;
            trackBar2.Scroll += trackBar2_Scroll;
            // 
            // trackBar3
            // 
            trackBar3.Location = new Point(184, 431);
            trackBar3.Maximum = 1023;
            trackBar3.Name = "trackBar3";
            trackBar3.Orientation = Orientation.Vertical;
            trackBar3.Size = new Size(45, 281);
            trackBar3.TabIndex = 7;
            trackBar3.Value = 512;
            trackBar3.Scroll += trackBar3_Scroll;
            // 
            // trackBar4
            // 
            trackBar4.Location = new Point(260, 431);
            trackBar4.Maximum = 1023;
            trackBar4.Name = "trackBar4";
            trackBar4.Orientation = Orientation.Vertical;
            trackBar4.Size = new Size(45, 281);
            trackBar4.TabIndex = 6;
            trackBar4.Value = 512;
            trackBar4.Scroll += trackBar4_Scroll;
            // 
            // trackBar5
            // 
            trackBar5.Location = new Point(338, 431);
            trackBar5.Maximum = 1023;
            trackBar5.Name = "trackBar5";
            trackBar5.Orientation = Orientation.Vertical;
            trackBar5.Size = new Size(45, 281);
            trackBar5.TabIndex = 11;
            trackBar5.Value = 512;
            trackBar5.Scroll += trackBar5_Scroll;
            // 
            // trackBar6
            // 
            trackBar6.Location = new Point(417, 431);
            trackBar6.Maximum = 1023;
            trackBar6.Name = "trackBar6";
            trackBar6.Orientation = Orientation.Vertical;
            trackBar6.Size = new Size(45, 281);
            trackBar6.TabIndex = 10;
            trackBar6.Value = 512;
            trackBar6.Scroll += trackBar6_Scroll;
            // 
            // trackBar7
            // 
            trackBar7.Location = new Point(495, 431);
            trackBar7.Maximum = 1023;
            trackBar7.Name = "trackBar7";
            trackBar7.Orientation = Orientation.Vertical;
            trackBar7.Size = new Size(45, 281);
            trackBar7.TabIndex = 9;
            trackBar7.Value = 512;
            trackBar7.Scroll += trackBar7_Scroll;
            // 
            // trackBar8
            // 
            trackBar8.Location = new Point(571, 431);
            trackBar8.Maximum = 1023;
            trackBar8.Name = "trackBar8";
            trackBar8.Orientation = Orientation.Vertical;
            trackBar8.Size = new Size(45, 281);
            trackBar8.TabIndex = 8;
            trackBar8.Value = 512;
            trackBar8.Scroll += trackBar8_Scroll;
            // 
            // trackBar9
            // 
            trackBar9.Location = new Point(649, 431);
            trackBar9.Maximum = 1023;
            trackBar9.Name = "trackBar9";
            trackBar9.Orientation = Orientation.Vertical;
            trackBar9.Size = new Size(45, 281);
            trackBar9.TabIndex = 13;
            trackBar9.Value = 512;
            trackBar9.Scroll += trackBar9_Scroll;
            // 
            // trackBar10
            // 
            trackBar10.Location = new Point(728, 431);
            trackBar10.Maximum = 1023;
            trackBar10.Name = "trackBar10";
            trackBar10.Orientation = Orientation.Vertical;
            trackBar10.Size = new Size(45, 281);
            trackBar10.TabIndex = 12;
            trackBar10.Value = 512;
            trackBar10.Scroll += trackBar10_Scroll;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(555, 12);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(104, 19);
            checkBox1.TabIndex = 14;
            checkBox1.Text = "Moving Faders";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // button3
            // 
            button3.Location = new Point(184, 386);
            button3.Name = "button3";
            button3.Size = new Size(43, 39);
            button3.TabIndex = 15;
            button3.Tag = "ON";
            button3.Text = "ON";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(260, 386);
            button4.Name = "button4";
            button4.Size = new Size(43, 39);
            button4.TabIndex = 16;
            button4.Tag = "ON";
            button4.Text = "ON";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(338, 386);
            button5.Name = "button5";
            button5.Size = new Size(43, 39);
            button5.TabIndex = 17;
            button5.Tag = "ON";
            button5.Text = "ON";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(417, 386);
            button6.Name = "button6";
            button6.Size = new Size(43, 39);
            button6.TabIndex = 18;
            button6.Tag = "ON";
            button6.Text = "ON";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(495, 386);
            button7.Name = "button7";
            button7.Size = new Size(43, 39);
            button7.TabIndex = 19;
            button7.Tag = "ON";
            button7.Text = "ON";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(571, 386);
            button8.Name = "button8";
            button8.Size = new Size(43, 39);
            button8.TabIndex = 20;
            button8.Tag = "ON";
            button8.Text = "ON";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(649, 386);
            button9.Name = "button9";
            button9.Size = new Size(43, 39);
            button9.TabIndex = 21;
            button9.Tag = "ON";
            button9.Text = "ON";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(730, 386);
            button10.Name = "button10";
            button10.Size = new Size(43, 39);
            button10.TabIndex = 22;
            button10.Tag = "ON";
            button10.Text = "ON";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(876, 12);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(360, 694);
            listBox1.TabIndex = 23;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            listBox1.DataContextChanged += listBox1_DataContextChanged;
            // 
            // button11
            // 
            button11.Location = new Point(28, 331);
            button11.Name = "button11";
            button11.Size = new Size(43, 39);
            button11.TabIndex = 33;
            button11.Tag = "ON";
            button11.Text = "ON";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(104, 331);
            button12.Name = "button12";
            button12.Size = new Size(43, 39);
            button12.TabIndex = 32;
            button12.Tag = "ON";
            button12.Text = "ON";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(184, 331);
            button13.Name = "button13";
            button13.Size = new Size(43, 39);
            button13.TabIndex = 31;
            button13.Tag = "ON";
            button13.Text = "ON";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(262, 331);
            button14.Name = "button14";
            button14.Size = new Size(43, 39);
            button14.TabIndex = 30;
            button14.Tag = "ON";
            button14.Text = "ON";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Location = new Point(338, 331);
            button15.Name = "button15";
            button15.Size = new Size(43, 39);
            button15.TabIndex = 29;
            button15.Tag = "ON";
            button15.Text = "ON";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Location = new Point(417, 331);
            button16.Name = "button16";
            button16.Size = new Size(43, 39);
            button16.TabIndex = 28;
            button16.Tag = "ON";
            button16.Text = "ON";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Location = new Point(495, 331);
            button17.Name = "button17";
            button17.Size = new Size(43, 39);
            button17.TabIndex = 27;
            button17.Tag = "ON";
            button17.Text = "ON";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(573, 331);
            button18.Name = "button18";
            button18.Size = new Size(43, 39);
            button18.TabIndex = 26;
            button18.Tag = "ON";
            button18.Text = "ON";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Location = new Point(649, 331);
            button19.Name = "button19";
            button19.Size = new Size(43, 39);
            button19.TabIndex = 25;
            button19.Tag = "ON";
            button19.Text = "ON";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(730, 331);
            button20.Name = "button20";
            button20.Size = new Size(45, 39);
            button20.TabIndex = 24;
            button20.Tag = "ON";
            button20.Text = "ON";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Location = new Point(12, 289);
            button21.Name = "button21";
            button21.Size = new Size(33, 26);
            button21.TabIndex = 53;
            button21.Tag = "ON";
            button21.Text = "ON";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.Location = new Point(91, 288);
            button22.Name = "button22";
            button22.Size = new Size(33, 26);
            button22.TabIndex = 52;
            button22.Tag = "ON";
            button22.Text = "ON";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.Location = new Point(169, 288);
            button23.Name = "button23";
            button23.Size = new Size(33, 26);
            button23.TabIndex = 51;
            button23.Tag = "ON";
            button23.Text = "ON";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // button24
            // 
            button24.Location = new Point(247, 288);
            button24.Name = "button24";
            button24.Size = new Size(33, 26);
            button24.TabIndex = 50;
            button24.Tag = "ON";
            button24.Text = "ON";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // button25
            // 
            button25.Location = new Point(325, 288);
            button25.Name = "button25";
            button25.Size = new Size(33, 26);
            button25.TabIndex = 49;
            button25.Tag = "ON";
            button25.Text = "ON";
            button25.UseVisualStyleBackColor = true;
            button25.Click += button25_Click;
            // 
            // button26
            // 
            button26.Location = new Point(403, 288);
            button26.Name = "button26";
            button26.Size = new Size(33, 26);
            button26.TabIndex = 48;
            button26.Tag = "ON";
            button26.Text = "ON";
            button26.UseVisualStyleBackColor = true;
            button26.Click += button26_Click;
            // 
            // button27
            // 
            button27.Location = new Point(481, 288);
            button27.Name = "button27";
            button27.Size = new Size(33, 26);
            button27.TabIndex = 47;
            button27.Tag = "ON";
            button27.Text = "ON";
            button27.UseVisualStyleBackColor = true;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Location = new Point(559, 288);
            button28.Name = "button28";
            button28.Size = new Size(33, 26);
            button28.TabIndex = 46;
            button28.Tag = "ON";
            button28.Text = "ON";
            button28.UseVisualStyleBackColor = true;
            button28.Click += button28_Click;
            // 
            // button29
            // 
            button29.Location = new Point(637, 288);
            button29.Name = "button29";
            button29.Size = new Size(33, 26);
            button29.TabIndex = 45;
            button29.Tag = "ON";
            button29.Text = "ON";
            button29.UseVisualStyleBackColor = true;
            button29.Click += button29_Click;
            // 
            // button30
            // 
            button30.Location = new Point(715, 288);
            button30.Name = "button30";
            button30.Size = new Size(33, 26);
            button30.TabIndex = 44;
            button30.Tag = "ON";
            button30.Text = "ON";
            button30.UseVisualStyleBackColor = true;
            button30.Click += button30_Click;
            // 
            // button31
            // 
            button31.Location = new Point(52, 288);
            button31.Name = "button31";
            button31.Size = new Size(33, 26);
            button31.TabIndex = 43;
            button31.Tag = "ON";
            button31.Text = "ON";
            button31.UseVisualStyleBackColor = true;
            button31.Click += button31_Click;
            // 
            // button32
            // 
            button32.Location = new Point(130, 289);
            button32.Name = "button32";
            button32.Size = new Size(33, 26);
            button32.TabIndex = 42;
            button32.Tag = "ON";
            button32.Text = "ON";
            button32.UseVisualStyleBackColor = true;
            button32.Click += button32_Click;
            // 
            // button33
            // 
            button33.Location = new Point(208, 288);
            button33.Name = "button33";
            button33.Size = new Size(33, 26);
            button33.TabIndex = 41;
            button33.Tag = "ON";
            button33.Text = "ON";
            button33.UseVisualStyleBackColor = true;
            button33.Click += button33_Click;
            // 
            // button34
            // 
            button34.Location = new Point(286, 288);
            button34.Name = "button34";
            button34.Size = new Size(33, 26);
            button34.TabIndex = 40;
            button34.Tag = "ON";
            button34.Text = "ON";
            button34.UseVisualStyleBackColor = true;
            button34.Click += button34_Click;
            // 
            // button35
            // 
            button35.Location = new Point(364, 288);
            button35.Name = "button35";
            button35.Size = new Size(33, 26);
            button35.TabIndex = 39;
            button35.Tag = "ON";
            button35.Text = "ON";
            button35.UseVisualStyleBackColor = true;
            button35.Click += button35_Click;
            // 
            // button36
            // 
            button36.Location = new Point(442, 288);
            button36.Name = "button36";
            button36.Size = new Size(33, 26);
            button36.TabIndex = 38;
            button36.Tag = "ON";
            button36.Text = "ON";
            button36.UseVisualStyleBackColor = true;
            button36.Click += button36_Click;
            // 
            // button37
            // 
            button37.Location = new Point(520, 288);
            button37.Name = "button37";
            button37.Size = new Size(33, 26);
            button37.TabIndex = 37;
            button37.Tag = "ON";
            button37.Text = "ON";
            button37.UseVisualStyleBackColor = true;
            button37.Click += button37_Click;
            // 
            // button38
            // 
            button38.Location = new Point(598, 287);
            button38.Name = "button38";
            button38.Size = new Size(33, 26);
            button38.TabIndex = 36;
            button38.Tag = "ON";
            button38.Text = "ON";
            button38.UseVisualStyleBackColor = true;
            button38.Click += button38_Click;
            // 
            // button39
            // 
            button39.Location = new Point(676, 288);
            button39.Name = "button39";
            button39.Size = new Size(33, 26);
            button39.TabIndex = 35;
            button39.Tag = "ON";
            button39.Text = "ON";
            button39.UseVisualStyleBackColor = true;
            button39.Click += button39_Click;
            // 
            // button40
            // 
            button40.Location = new Point(754, 287);
            button40.Name = "button40";
            button40.Size = new Size(33, 26);
            button40.TabIndex = 34;
            button40.Tag = "ON";
            button40.Text = "ON";
            button40.UseVisualStyleBackColor = true;
            button40.Click += button40_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 10;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1248, 745);
            Controls.Add(button21);
            Controls.Add(button22);
            Controls.Add(button23);
            Controls.Add(button24);
            Controls.Add(button25);
            Controls.Add(button26);
            Controls.Add(button27);
            Controls.Add(button28);
            Controls.Add(button29);
            Controls.Add(button30);
            Controls.Add(button31);
            Controls.Add(button32);
            Controls.Add(button33);
            Controls.Add(button34);
            Controls.Add(button35);
            Controls.Add(button36);
            Controls.Add(button37);
            Controls.Add(button38);
            Controls.Add(button39);
            Controls.Add(button40);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(listBox1);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(checkBox1);
            Controls.Add(trackBar9);
            Controls.Add(trackBar10);
            Controls.Add(trackBar5);
            Controls.Add(trackBar6);
            Controls.Add(trackBar7);
            Controls.Add(trackBar8);
            Controls.Add(trackBar3);
            Controls.Add(trackBar4);
            Controls.Add(trackBar2);
            Controls.Add(button2);
            Controls.Add(trackBar1);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            Shown += Form1_Shown;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private TextBox textBox2;
        private TrackBar trackBar1;
        private Button button2;
        private TrackBar trackBar2;
        private TrackBar trackBar3;
        private TrackBar trackBar4;
        private TrackBar trackBar5;
        private TrackBar trackBar6;
        private TrackBar trackBar7;
        private TrackBar trackBar8;
        private TrackBar trackBar9;
        private TrackBar trackBar10;
        private CheckBox checkBox1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        public ListBox listBox1;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private Button button39;
        private Button button40;
        private System.Windows.Forms.Timer timer1;
    }
}
