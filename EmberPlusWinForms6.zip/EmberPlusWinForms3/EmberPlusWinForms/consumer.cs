﻿
namespace EmberPlusWinForms
{
    internal class consumer
    {
        internal static async Task SendAsync()
        {
            throw new NotImplementedException();
        }
    }
}