﻿namespace EmberPlusWinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            timer1 = new System.Windows.Forms.Timer(components);
            button1 = new Button();
            textBox2 = new TextBox();
            trackBar1 = new TrackBar();
            button2 = new Button();
            trackBar2 = new TrackBar();
            trackBar3 = new TrackBar();
            trackBar4 = new TrackBar();
            trackBar5 = new TrackBar();
            trackBar6 = new TrackBar();
            trackBar7 = new TrackBar();
            trackBar8 = new TrackBar();
            trackBar9 = new TrackBar();
            trackBar10 = new TrackBar();
            checkBox1 = new CheckBox();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            listBox1 = new ListBox();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).BeginInit();
            SuspendLayout();
            // 
            // timer1
            // 
            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            // 
            // button1
            // 
            button1.Location = new Point(26, 243);
            button1.Name = "button1";
            button1.Size = new Size(45, 39);
            button1.TabIndex = 1;
            button1.Tag = "ON";
            button1.Text = "ON";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(93, 12);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(434, 23);
            textBox2.TabIndex = 2;
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(26, 288);
            trackBar1.Maximum = 1023;
            trackBar1.Name = "trackBar1";
            trackBar1.Orientation = Orientation.Vertical;
            trackBar1.Size = new Size(45, 281);
            trackBar1.TabIndex = 3;
            trackBar1.Value = 512;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // button2
            // 
            button2.Location = new Point(93, 243);
            button2.Name = "button2";
            button2.Size = new Size(43, 39);
            button2.TabIndex = 4;
            button2.Tag = "ON";
            button2.Text = "ON";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // trackBar2
            // 
            trackBar2.Location = new Point(91, 288);
            trackBar2.Maximum = 1023;
            trackBar2.Name = "trackBar2";
            trackBar2.Orientation = Orientation.Vertical;
            trackBar2.Size = new Size(45, 281);
            trackBar2.TabIndex = 5;
            trackBar2.Value = 512;
            trackBar2.Scroll += trackBar2_Scroll;
            // 
            // trackBar3
            // 
            trackBar3.Location = new Point(158, 288);
            trackBar3.Maximum = 1023;
            trackBar3.Name = "trackBar3";
            trackBar3.Orientation = Orientation.Vertical;
            trackBar3.Size = new Size(45, 281);
            trackBar3.TabIndex = 7;
            trackBar3.Value = 512;
            trackBar3.Scroll += trackBar3_Scroll;
            // 
            // trackBar4
            // 
            trackBar4.Location = new Point(224, 288);
            trackBar4.Maximum = 1023;
            trackBar4.Name = "trackBar4";
            trackBar4.Orientation = Orientation.Vertical;
            trackBar4.Size = new Size(45, 281);
            trackBar4.TabIndex = 6;
            trackBar4.Value = 512;
            trackBar4.Scroll += trackBar4_Scroll;
            // 
            // trackBar5
            // 
            trackBar5.Location = new Point(293, 288);
            trackBar5.Maximum = 1023;
            trackBar5.Name = "trackBar5";
            trackBar5.Orientation = Orientation.Vertical;
            trackBar5.Size = new Size(45, 281);
            trackBar5.TabIndex = 11;
            trackBar5.Value = 512;
            trackBar5.Scroll += trackBar5_Scroll;
            // 
            // trackBar6
            // 
            trackBar6.Location = new Point(365, 288);
            trackBar6.Maximum = 1023;
            trackBar6.Name = "trackBar6";
            trackBar6.Orientation = Orientation.Vertical;
            trackBar6.Size = new Size(45, 281);
            trackBar6.TabIndex = 10;
            trackBar6.Value = 512;
            trackBar6.Scroll += trackBar6_Scroll;
            // 
            // trackBar7
            // 
            trackBar7.Location = new Point(434, 288);
            trackBar7.Maximum = 1023;
            trackBar7.Name = "trackBar7";
            trackBar7.Orientation = Orientation.Vertical;
            trackBar7.Size = new Size(45, 281);
            trackBar7.TabIndex = 9;
            trackBar7.Value = 512;
            trackBar7.Scroll += trackBar7_Scroll;
            // 
            // trackBar8
            // 
            trackBar8.Location = new Point(498, 288);
            trackBar8.Maximum = 1023;
            trackBar8.Name = "trackBar8";
            trackBar8.Orientation = Orientation.Vertical;
            trackBar8.Size = new Size(45, 281);
            trackBar8.TabIndex = 8;
            trackBar8.Value = 512;
            trackBar8.Scroll += trackBar8_Scroll;
            // 
            // trackBar9
            // 
            trackBar9.Location = new Point(570, 288);
            trackBar9.Maximum = 1023;
            trackBar9.Name = "trackBar9";
            trackBar9.Orientation = Orientation.Vertical;
            trackBar9.Size = new Size(45, 281);
            trackBar9.TabIndex = 13;
            trackBar9.Value = 512;
            trackBar9.Scroll += trackBar9_Scroll;
            // 
            // trackBar10
            // 
            trackBar10.Location = new Point(645, 288);
            trackBar10.Maximum = 1023;
            trackBar10.Name = "trackBar10";
            trackBar10.Orientation = Orientation.Vertical;
            trackBar10.Size = new Size(45, 281);
            trackBar10.TabIndex = 12;
            trackBar10.Value = 512;
            trackBar10.Scroll += trackBar10_Scroll;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(555, 12);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(104, 19);
            checkBox1.TabIndex = 14;
            checkBox1.Text = "Moving Faders";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // button3
            // 
            button3.Location = new Point(158, 243);
            button3.Name = "button3";
            button3.Size = new Size(43, 39);
            button3.TabIndex = 15;
            button3.Tag = "ON";
            button3.Text = "ON";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(224, 243);
            button4.Name = "button4";
            button4.Size = new Size(43, 39);
            button4.TabIndex = 16;
            button4.Tag = "ON";
            button4.Text = "ON";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(293, 243);
            button5.Name = "button5";
            button5.Size = new Size(43, 39);
            button5.TabIndex = 17;
            button5.Tag = "ON";
            button5.Text = "ON";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(365, 243);
            button6.Name = "button6";
            button6.Size = new Size(43, 39);
            button6.TabIndex = 18;
            button6.Tag = "ON";
            button6.Text = "ON";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(434, 243);
            button7.Name = "button7";
            button7.Size = new Size(43, 39);
            button7.TabIndex = 19;
            button7.Tag = "ON";
            button7.Text = "ON";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(498, 243);
            button8.Name = "button8";
            button8.Size = new Size(43, 39);
            button8.TabIndex = 20;
            button8.Tag = "ON";
            button8.Text = "ON";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(570, 243);
            button9.Name = "button9";
            button9.Size = new Size(43, 39);
            button9.TabIndex = 21;
            button9.Tag = "ON";
            button9.Text = "ON";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(647, 243);
            button10.Name = "button10";
            button10.Size = new Size(43, 39);
            button10.TabIndex = 22;
            button10.Tag = "ON";
            button10.Text = "ON";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(266, 46);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(661, 94);
            listBox1.TabIndex = 23;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            listBox1.DataContextChanged += listBox1_DataContextChanged;
            // 
            // button11
            // 
            button11.Location = new Point(647, 188);
            button11.Name = "button11";
            button11.Size = new Size(43, 39);
            button11.TabIndex = 33;
            button11.Tag = "ON";
            button11.Text = "ON";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(570, 188);
            button12.Name = "button12";
            button12.Size = new Size(43, 39);
            button12.TabIndex = 32;
            button12.Tag = "ON";
            button12.Text = "ON";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(498, 188);
            button13.Name = "button13";
            button13.Size = new Size(43, 39);
            button13.TabIndex = 31;
            button13.Tag = "ON";
            button13.Text = "ON";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(434, 188);
            button14.Name = "button14";
            button14.Size = new Size(43, 39);
            button14.TabIndex = 30;
            button14.Tag = "ON";
            button14.Text = "ON";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(365, 188);
            button15.Name = "button15";
            button15.Size = new Size(43, 39);
            button15.TabIndex = 29;
            button15.Tag = "ON";
            button15.Text = "ON";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(293, 188);
            button16.Name = "button16";
            button16.Size = new Size(43, 39);
            button16.TabIndex = 28;
            button16.Tag = "ON";
            button16.Text = "ON";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(224, 188);
            button17.Name = "button17";
            button17.Size = new Size(43, 39);
            button17.TabIndex = 27;
            button17.Tag = "ON";
            button17.Text = "ON";
            button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(158, 188);
            button18.Name = "button18";
            button18.Size = new Size(43, 39);
            button18.TabIndex = 26;
            button18.Tag = "ON";
            button18.Text = "ON";
            button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(93, 188);
            button19.Name = "button19";
            button19.Size = new Size(43, 39);
            button19.TabIndex = 25;
            button19.Tag = "ON";
            button19.Text = "ON";
            button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(26, 188);
            button20.Name = "button20";
            button20.Size = new Size(45, 39);
            button20.TabIndex = 24;
            button20.Tag = "ON";
            button20.Text = "ON";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(939, 581);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(listBox1);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(checkBox1);
            Controls.Add(trackBar9);
            Controls.Add(trackBar10);
            Controls.Add(trackBar5);
            Controls.Add(trackBar6);
            Controls.Add(trackBar7);
            Controls.Add(trackBar8);
            Controls.Add(trackBar3);
            Controls.Add(trackBar4);
            Controls.Add(trackBar2);
            Controls.Add(button2);
            Controls.Add(trackBar1);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            Shown += Form1_Shown;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private TextBox textBox2;
        private TrackBar trackBar1;
        private Button button2;
        private TrackBar trackBar2;
        private TrackBar trackBar3;
        private TrackBar trackBar4;
        private TrackBar trackBar5;
        private TrackBar trackBar6;
        private TrackBar trackBar7;
        private TrackBar trackBar8;
        private TrackBar trackBar9;
        private TrackBar trackBar10;
        private CheckBox checkBox1;
        public System.Windows.Forms.Timer timer1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        public ListBox listBox1;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
    }
}
