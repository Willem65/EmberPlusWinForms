﻿using Lawo;
using Lawo.EmberPlusSharp.Model;
using Lawo.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static EmberPlusWinForms.GetSet;
using static System.Windows.Forms.AxHost;
using Button = System.Windows.Forms.Button;

namespace EmberPlusWinForms
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    class ButtonManager
    {
        private readonly List<IParameter> _parameters;
        private readonly List<Button> _buttons;
        private readonly Form _form;

        public ButtonManager(Form form, List<IParameter> parameters, List<Button> buttons)
        {
            _form = form;
            _parameters = parameters;
            _buttons = buttons;
        }

        public void InitializeButtons()
        {
            //for (int i = 0; i < _buttons.Count && i < _parameters.Count; i++)
                for (int i = 0; i < 20; i++)
                {
                var index = i;
                var button = _buttons[i];
                var parameter = _parameters[i];



                // Handle incoming data (Ember+ updates UI)
                parameter.PropertyChanged += (sender, args) =>
                {
                    bool updatedValue = (bool)((IParameter)sender).Value;

                    _form.BeginInvoke((Action)(() =>
                    {
                        button.BackColor = updatedValue ? Color.Red : Color.Green;

                        // Log the incoming value
                        Form1.instanse.listBox1.Items.Add($"IN <---- Button[{index}] Param: {updatedValue}");
                        Form1.instanse.listBox1.SelectedIndex = Form1.instanse.listBox1.Items.Count - 1;
                    }));
                };

                // Handle outgoing data (Button click sends value to Ember+)
                button.Click += async (s, e) =>
                {
                    await SyncButtonToEmberAsync(button, parameter, index);
                };
            }
        }

        /// <summary>
        /// Sends the button state to the parameter when clicked.
        /// </summary>
        private async Task SyncButtonToEmberAsync(Button button, IParameter parameter, int index)
        {
            // Ensure Tag is a boolean
            if (button.Tag is bool state)
            {
                parameter.Value = state;
                // parameter.Value = state ? (Boolean)1 : (bool)0; // Fix: convert bool to long
                Form1.instanse.listBox1.Items.Add($"OUT ----> Button[{index}] Tag: {state}");
                Form1.instanse.listBox1.SelectedIndex = Form1.instanse.listBox1.Items.Count - 1;
            }
            // Simulate async work (optional)
            await Task.CompletedTask;
        }
    }

}
