﻿using Lawo.EmberPlusSharp.Model;
using Lawo.EmberPlusSharp.S101;
using System.Net.Sockets;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace EmberPlusWinForms
{
    public partial class Form1 : Form
    {
        public static Form1 Instance;  // Now you can access the form from static code
        bool checkboxEnabled = false;
        //private dynamic fader;
        

        public Form1()
        {
            //timer1.Start();
            InitializeComponent();
            Instance = this;
            // Subscribe to the CheckedChanged event
            checkBox1.CheckedChanged += CheckBox1_CheckedChanged;
            

        }



        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Stop();
            Task startEmberPlusListenerAsync = StartEmberPlusListenerAsync();
            
        }

        private static async Task<S101Client> ConnectAsync(string host, int port)
        {
            var tcpClient = new TcpClient();
            await tcpClient.ConnectAsync(host, port);
            var stream = tcpClient.GetStream();
            Thread.Sleep(100);

            return new S101Client(tcpClient, stream.ReadAsync, stream.WriteAsync);

        }

        private sealed class MyRoot : DynamicRoot<MyRoot>
        {
        }

        ////public async Task StartEmberPlusListenerAsync()
        ////{
        ////    using (S101Client client = await ConnectAsync("192.168.1.2", 9000))
        ////    using (Consumer<MyRoot> consumer = await Consumer<MyRoot>.CreateAsync(client))
        ////    {
        ////        Thread.Sleep(100);
        ////        INode root = consumer.Root;
        ////        //var faderPosition = (IParameter)root.GetElement("/Sapphire/Sources/FPGM 1/Fader/Position");
        ////        var faderPosition = (IParameter)root.GetElement("/auron/modules/module_1/level");
        ////        var faderPosition2 = (IParameter)root.GetElement("/auron/modules/module_2/level");

        ////        faderPosition.PropertyChanged += (sender, args) =>
        ////        {
        ////            //var updatedValue = ((dynamic)sender).Value;
        ////            //var updatedValue = Convert.ToInt32(((IParameter)sender).Value);
        ////            var updatedValue = (long)((IParameter)sender).Value;
        ////            this.BeginInvoke((Action)(() =>
        ////            {
        ////                var parameter = sender as IParameter;
        ////                if (parameter != null)
        ////                {
        ////                    textBox1.AppendText($"[IN] Fader.Position changed: {((IParameter)sender).Value}\r\n");
        ////                    int clampedValue = Math.Min(Math.Max((int)updatedValue, trackBar1.Minimum), trackBar1.Maximum);
        ////                    if (trackBar1.Value != clampedValue)
        ////                        trackBar1.Value = clampedValue;
        ////                }
        ////            }));
        ////        };

        ////        trackBar1.Scroll += async (s, e) =>
        ////        {
        ////            int newValue = trackBar1.Value;

        ////            faderPosition.Value = (long)newValue;
        ////            //await consumer.SendAsync();

        ////            textBox1.AppendText($"[OUT] Sent Fader.Position: {newValue}\r\n");
        ////        };
        ////       // await Task.Delay(Timeout.Infinite); // Keep app alive


        ////        faderPosition2.PropertyChanged += (sender, args) =>
        ////        {
        ////            //var updatedValue = ((dynamic)sender).Value;
        ////            //var updatedValue = Convert.ToInt32(((IParameter)sender).Value);
        ////            var updatedValue2 = (long)((IParameter)sender).Value;
        ////            this.BeginInvoke((Action)(() =>
        ////            {
        ////                var parameter2 = sender as IParameter;
        ////                if (parameter2 != null)
        ////                {
        ////                    textBox1.AppendText($"[IN] Fader.Position changed: {((IParameter)sender).Value}\r\n");
        ////                    int clampedValue = Math.Min(Math.Max((int)updatedValue2, trackBar2.Minimum), trackBar2.Maximum);
        ////                    if (trackBar2.Value != clampedValue)
        ////                        trackBar2.Value = clampedValue;
        ////                }
        ////            }));
        ////        };

        ////        trackBar2.Scroll += async (s, e) =>
        ////        {
        ////            int newValue = trackBar2.Value;

        ////            faderPosition2.Value = (long)newValue;
        ////           // await consumer.SendAsync();

        ////            textBox1.AppendText($"[OUT] Sent Fader.Position: {newValue}\r\n");
        ////        };
        ////        await Task.Delay(Timeout.Infinite); // Keep app alive



        ////    }
        ////}
        ///


        private void BindFader(IParameter fader, TrackBar trackBar, string label)
        {
            fader.PropertyChanged += (sender, args) =>
            {
                var updatedValue = (long)((IParameter)sender).Value;
                this.BeginInvoke((Action)(() =>
                {
                    var parameter = sender as IParameter;
                    if (parameter != null)
                    {
                        textBox1.AppendText($"[IN] {label} changed: {updatedValue}\r\n");
                        int clampedValue = Math.Min(Math.Max((int)updatedValue, trackBar.Minimum), trackBar.Maximum);
                        if (trackBar.Value != clampedValue)
                            trackBar.Value = clampedValue;
                    }
                }));
            };

            trackBar.ValueChanged += async (s, e) =>
            {

                int newValue = trackBar.Value;
                fader.Value = (long)newValue;
                //await consumer.SendAsync(); // <-- This makes the change go live on the Ember+ device
                textBox1.AppendText($"[OUT] Sent {label}: {newValue}\r\n");

            };

        }





        public async Task StartEmberPlusListenerAsync()
        {
            using (S101Client client = await ConnectAsync("192.168.1.2", 9000))
            using (Consumer<MyRoot> consumer = await Consumer<MyRoot>.CreateAsync(client))
            {
                Thread.Sleep(100);
                INode root = consumer.Root;

                var faderPosition1 = (IParameter)root.GetElement("/auron/modules/module_1/level");
                var faderPosition2 = (IParameter)root.GetElement("/auron/modules/module_2/level");
                var faderPosition3 = (IParameter)root.GetElement("/auron/modules/module_3/level");
                var faderPosition4 = (IParameter)root.GetElement("/auron/modules/module_4/level");
                var faderPosition5 = (IParameter)root.GetElement("/auron/modules/module_5/level");
                var faderPosition6 = (IParameter)root.GetElement("/auron/modules/module_6/level");
                var faderPosition7 = (IParameter)root.GetElement("/auron/modules/module_7/level");
                var faderPosition8 = (IParameter)root.GetElement("/auron/modules/module_8/level");
                var faderPosition9 = (IParameter)root.GetElement("/auron/modules/module_9/level");
                var faderPosition10 = (IParameter)root.GetElement("/auron/modules/module_10/level");

                BindFader(faderPosition1, trackBar1, "Module 1 Level");
                BindFader(faderPosition2, trackBar2, "Module 2 Level");
                BindFader(faderPosition3, trackBar3, "Module 3 Level");
                BindFader(faderPosition4, trackBar4, "Module 4 Level");
                BindFader(faderPosition5, trackBar5, "Module 5 Level");
                BindFader(faderPosition6, trackBar6, "Module 6 Level");
                BindFader(faderPosition7, trackBar7, "Module 7 Level");
                BindFader(faderPosition8, trackBar8, "Module 8 Level");
                BindFader(faderPosition9, trackBar9, "Module 9 Level");
                BindFader(faderPosition10, trackBar10, "Module 10 Level");


                await Task.Delay(Timeout.Infinite); // Keep app alive

            }

        }





        private void button1_Click(object sender, EventArgs e)
        {
            Task startEmberPlusListenerAsync = StartEmberPlusListenerAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Task emberTreePlusListenerAsync = EmberTreePlusListenerAsync();            
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar8_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar7_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar6_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar10_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar9_Scroll(object sender, EventArgs e)
        {

        }

        private void Form1_Activated(object sender, EventArgs e)
        {

        }

        static int tellertje;

        private void timer1_Tick(object sender, EventArgs e)
        {
            // for (int tellertje = 0; tellertje < 1023; tellertje++)
            // {
            tellertje = tellertje + 20;
            trackBar1.Value = tellertje;
            trackBar2.Value = tellertje;
            trackBar3.Value = tellertje;
            trackBar4.Value = tellertje;
            trackBar5.Value = tellertje;
            trackBar6.Value = tellertje;
            trackBar7.Value = tellertje;
            trackBar8.Value = tellertje;
            trackBar9.Value = tellertje;
            trackBar10.Value = tellertje;
            if (tellertje > 1000)
                tellertje = 0;
            //}
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            //timer1.Enabled = true;

        }
        private void CheckBox1_CheckedChanged(object? sender, EventArgs e)
        {
           
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                timer1.Start();
            else
                timer1.Stop();
        }
    }
}




