﻿namespace EmberPlusWinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            timer1 = new System.Windows.Forms.Timer(components);
            textBox1 = new TextBox();
            button1 = new Button();
            textBox2 = new TextBox();
            trackBar1 = new TrackBar();
            button2 = new Button();
            trackBar2 = new TrackBar();
            trackBar3 = new TrackBar();
            trackBar4 = new TrackBar();
            trackBar5 = new TrackBar();
            trackBar6 = new TrackBar();
            trackBar7 = new TrackBar();
            trackBar8 = new TrackBar();
            trackBar9 = new TrackBar();
            trackBar10 = new TrackBar();
            checkBox1 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).BeginInit();
            SuspendLayout();
            // 
            // timer1
            // 
            timer1.Interval = 2;
            timer1.Tick += timer1_Tick;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(700, 13);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Size = new Size(215, 144);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(93, 12);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(434, 23);
            textBox2.TabIndex = 2;
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(28, 167);
            trackBar1.Maximum = 1023;
            trackBar1.Name = "trackBar1";
            trackBar1.Orientation = Orientation.Vertical;
            trackBar1.Size = new Size(45, 281);
            trackBar1.TabIndex = 3;
            trackBar1.Value = 512;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // button2
            // 
            button2.Location = new Point(12, 62);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 4;
            button2.Text = "ReadTree";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // trackBar2
            // 
            trackBar2.Location = new Point(93, 167);
            trackBar2.Maximum = 1023;
            trackBar2.Name = "trackBar2";
            trackBar2.Orientation = Orientation.Vertical;
            trackBar2.Size = new Size(45, 281);
            trackBar2.TabIndex = 5;
            trackBar2.Value = 512;
            trackBar2.Scroll += trackBar2_Scroll;
            // 
            // trackBar3
            // 
            trackBar3.Location = new Point(160, 167);
            trackBar3.Maximum = 1023;
            trackBar3.Name = "trackBar3";
            trackBar3.Orientation = Orientation.Vertical;
            trackBar3.Size = new Size(45, 281);
            trackBar3.TabIndex = 7;
            trackBar3.Value = 512;
            trackBar3.Scroll += trackBar3_Scroll;
            // 
            // trackBar4
            // 
            trackBar4.Location = new Point(226, 167);
            trackBar4.Maximum = 1023;
            trackBar4.Name = "trackBar4";
            trackBar4.Orientation = Orientation.Vertical;
            trackBar4.Size = new Size(45, 281);
            trackBar4.TabIndex = 6;
            trackBar4.Value = 512;
            trackBar4.Scroll += trackBar4_Scroll;
            // 
            // trackBar5
            // 
            trackBar5.Location = new Point(295, 167);
            trackBar5.Maximum = 1023;
            trackBar5.Name = "trackBar5";
            trackBar5.Orientation = Orientation.Vertical;
            trackBar5.Size = new Size(45, 281);
            trackBar5.TabIndex = 11;
            trackBar5.Value = 512;
            trackBar5.Scroll += trackBar5_Scroll;
            // 
            // trackBar6
            // 
            trackBar6.Location = new Point(367, 167);
            trackBar6.Maximum = 1023;
            trackBar6.Name = "trackBar6";
            trackBar6.Orientation = Orientation.Vertical;
            trackBar6.Size = new Size(45, 281);
            trackBar6.TabIndex = 10;
            trackBar6.Value = 512;
            trackBar6.Scroll += trackBar6_Scroll;
            // 
            // trackBar7
            // 
            trackBar7.Location = new Point(436, 167);
            trackBar7.Maximum = 1023;
            trackBar7.Name = "trackBar7";
            trackBar7.Orientation = Orientation.Vertical;
            trackBar7.Size = new Size(45, 281);
            trackBar7.TabIndex = 9;
            trackBar7.Value = 512;
            trackBar7.Scroll += trackBar7_Scroll;
            // 
            // trackBar8
            // 
            trackBar8.Location = new Point(500, 167);
            trackBar8.Maximum = 1023;
            trackBar8.Name = "trackBar8";
            trackBar8.Orientation = Orientation.Vertical;
            trackBar8.Size = new Size(45, 281);
            trackBar8.TabIndex = 8;
            trackBar8.Value = 512;
            trackBar8.Scroll += trackBar8_Scroll;
            // 
            // trackBar9
            // 
            trackBar9.Location = new Point(572, 167);
            trackBar9.Maximum = 1023;
            trackBar9.Name = "trackBar9";
            trackBar9.Orientation = Orientation.Vertical;
            trackBar9.Size = new Size(45, 281);
            trackBar9.TabIndex = 13;
            trackBar9.Value = 512;
            trackBar9.Scroll += trackBar9_Scroll;
            // 
            // trackBar10
            // 
            trackBar10.Location = new Point(649, 167);
            trackBar10.Maximum = 1023;
            trackBar10.Name = "trackBar10";
            trackBar10.Orientation = Orientation.Vertical;
            trackBar10.Size = new Size(45, 281);
            trackBar10.TabIndex = 12;
            trackBar10.Value = 512;
            trackBar10.Scroll += trackBar10_Scroll;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(590, 12);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(83, 19);
            checkBox1.TabIndex = 14;
            checkBox1.Text = "checkBox1";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(927, 460);
            Controls.Add(checkBox1);
            Controls.Add(trackBar9);
            Controls.Add(trackBar10);
            Controls.Add(trackBar5);
            Controls.Add(trackBar6);
            Controls.Add(trackBar7);
            Controls.Add(trackBar8);
            Controls.Add(trackBar3);
            Controls.Add(trackBar4);
            Controls.Add(trackBar2);
            Controls.Add(button2);
            Controls.Add(trackBar1);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            Activated += Form1_Activated;
            Load += Form1_Load;
            Shown += Form1_Shown;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar3).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar4).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar5).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar6).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar7).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar8).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar9).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private TextBox textBox2;
        private TrackBar trackBar1;
        private Button button2;
        private TrackBar trackBar2;
        private TrackBar trackBar3;
        private TrackBar trackBar4;
        private TrackBar trackBar5;
        private TrackBar trackBar6;
        private TrackBar trackBar7;
        private TrackBar trackBar8;
        private TrackBar trackBar9;
        private TrackBar trackBar10;
        private CheckBox checkBox1;
        public System.Windows.Forms.Timer timer1;
    }
}
